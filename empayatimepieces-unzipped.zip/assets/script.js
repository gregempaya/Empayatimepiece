
// Basic cart + newsletter + appointment storage using localStorage
const CART_KEY = 'empaya_cart_v1';
const NEWS_KEY = 'empaya_newsletter_v1';
const APPT_KEY = 'empaya_appointments_v1';

function getCart(){ return JSON.parse(localStorage.getItem(CART_KEY) || '[]'); }
function setCart(c){ localStorage.setItem(CART_KEY, JSON.stringify(c)); updateCartCount(); }
function addToCart(item){
  const c = getCart();
  const idx = c.findIndex(x => x.id === item.id);
  if(idx >= 0){ c[idx].qty += item.qty || 1; } else { c.push({...item, qty: item.qty || 1}); }
  setCart(c);
  alert('Added to cart');
}
function removeFromCart(id){
  const c = getCart().filter(x => x.id !== id);
  setCart(c);
  renderCart && renderCart();
}
function updateQty(id, qty){
  const c = getCart();
  const it = c.find(x => x.id === id);
  if(it){ it.qty = Math.max(1, qty); setCart(c); renderCart && renderCart(); }
}
function cartTotal(){
  return getCart().reduce((s,x)=> s + x.price * x.qty, 0);
}
function updateCartCount(){
  const count = getCart().reduce((s,x)=> s + x.qty, 0);
  document.querySelectorAll('[data-cart-count]').forEach(el => el.textContent = count);
}

function money(n){ return '$' + n.toFixed(2); }

document.addEventListener('DOMContentLoaded', () => {
  updateCartCount();

  // Newsletter
  document.querySelectorAll('[data-newsletter]').forEach(form => {
    form.addEventListener('submit', e => {
      e.preventDefault();
      const email = form.querySelector('input[type="email"]').value.trim();
      if(!email) return;
      const store = JSON.parse(localStorage.getItem(NEWS_KEY) || '[]');
      store.push({email, at: new Date().toISOString()});
      localStorage.setItem(NEWS_KEY, JSON.stringify(store));
      form.reset();
      alert('Thanks for subscribing!');
    });
  });

  // Appointment
  const apptForm = document.querySelector('[data-appointment]');
  if(apptForm){
    apptForm.addEventListener('submit', e => {
      e.preventDefault();
      const data = Object.fromEntries(new FormData(apptForm).entries());
      const store = JSON.parse(localStorage.getItem(APPT_KEY) || '[]');
      store.push({...data, at: new Date().toISOString()});
      localStorage.setItem(APPT_KEY, JSON.stringify(store));
      apptForm.reset();
      alert('Appointment request received. We will confirm by email.');
    });
  }

  // Shop filtering
  const productGrid = document.querySelector('[data-products]');
  if(productGrid){
    fetch('assets/products.json').then(r=>r.json()).then(products => {
      window._products = products;
      renderProducts(products);
      const q = new URLSearchParams(location.search).get('q');
      if(q){ document.querySelector('[data-search]').value = q; applyFilters(); }
    });

    document.querySelectorAll('[data-filter], [data-search]').forEach(el => {
      el.addEventListener('change', applyFilters);
      el.addEventListener('input', applyFilters);
    });
  }

  // Cart page renderer
  if(document.querySelector('[data-cart]')){
    renderCart();
    document.querySelector('[data-checkout]').addEventListener('click', ()=>{
      const total = money(cartTotal());
      alert('Demo checkout — total ' + total + '. Connect to a payment provider to accept payments.');
    });
    document.querySelector('[data-clear]').addEventListener('click', ()=>{ setCart([]); renderCart(); });
  }
});

function renderProducts(items){
  const grid = document.querySelector('[data-products]');
  if(!grid) return;
  grid.innerHTML = '';
  if(!items.length){ grid.innerHTML = '<div class="empty">No products match your filters.</div>'; return; }
  items.forEach(p => {
    const el = document.createElement('div');
    el.className = 'card';
    el.innerHTML = `
      <img src="${p.image}" alt="${p.name}" loading="lazy">
      <div class="body">
        <div class="badge">${p.brand}</div>
        <h3 style="margin:.5rem 0;">${p.name}</h3>
        <div style="display:flex; justify-content:space-between; align-items:center;">
          <div class="price">${money(p.price)} ${p.compareAt ? '<span class="old">'+money(p.compareAt)+'</span>' : ''}</div>
          <button class="btn gold" aria-label="Add ${p.name} to cart">Add to cart</button>
        </div>
      </div>`;
    el.querySelector('button').addEventListener('click', ()=> addToCart({id:p.id, name:p.name, price:p.price}));
    grid.appendChild(el);
  });
}

function applyFilters(){
  const brand = document.querySelector('[data-filter="brand"]').value;
  const sort = document.querySelector('[data-filter="sort"]').value;
  const search = (document.querySelector('[data-search]').value || '').toLowerCase();
  let items = [...window._products];
  if(brand) items = items.filter(p => p.brand === brand);
  if(search) items = items.filter(p => (p.name + ' ' + p.tags.join(' ')).toLowerCase().includes(search));
  if(sort === 'price-asc') items.sort((a,b)=>a.price-b.price);
  if(sort === 'price-desc') items.sort((a,b)=>b.price-a.price);
  if(sort === 'name') items.sort((a,b)=>a.name.localeCompare(b.name));
  renderProducts(items);
}

// Cart rendering
function renderCart(){
  const cart = getCart();
  const tbody = document.querySelector('[data-cart-body]');
  const totalEl = document.querySelector('[data-cart-total]');
  tbody.innerHTML = '';
  cart.forEach(item => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${item.name}</td>
      <td>${money(item.price)}</td>
      <td><input type="number" min="1" value="${item.qty}" style="width:80px"></td>
      <td>${money(item.price * item.qty)}</td>
      <td><button class="btn outline">Remove</button></td>`;
    tr.querySelector('input').addEventListener('change', e => updateQty(item.id, parseInt(e.target.value,10)||1));
    tr.querySelector('button').addEventListener('click', ()=> removeFromCart(item.id));
    tbody.appendChild(tr);
  });
  totalEl.textContent = money(cartTotal());
}
